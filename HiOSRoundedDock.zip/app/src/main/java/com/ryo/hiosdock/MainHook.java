package com.ryo.hiosdock;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {
    static final String PKG = "com.transsion.hilauncher";
    static final String TAG = "ryo_rounded_dock";
    static final String[] HOTSEAT_IDS = {"hotseat", "dock", "dock_view", "hotseat_container", "workspace_hotseat"};

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Activity a = (Activity) param.thisObject;
                    if (!PKG.equals(a.getPackageName())) return;
                    if (!a.getClass().getName().toLowerCase().contains("launcher")) return;
                    attach(a);
                } catch (Throwable t) {
                    XposedBridge.log("RoundedDock: " + t);
                }
            }
        });
    }

    static void attach(final Activity a) {
        final ViewGroup content = a.findViewById(android.R.id.content);
        if (content == null || content.findViewWithTag(TAG) != null) return;

        final FrameLayout dock = new FrameLayout(a);
        dock.setTag(TAG);
        final float radius = dp(a, 34);
        dock.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
            }
        });
        dock.setClipToOutline(true);

        final BlurLayer blur = new BlurLayer(a);
        dock.addView(blur, new FrameLayout.LayoutParams(-1, -1));
        dock.addView(new GlassOverlay(a, radius), new FrameLayout.LayoutParams(-1, -1));
        dock.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> blur.refresh());

        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, dp(a, 100), Gravity.BOTTOM);
        p.leftMargin = p.rightMargin = dp(a, 14);
        p.bottomMargin = dp(a, 22);
        content.addView(dock, 0, p);   // index 0 = di belakang ikon launcher

        // ratakan dengan hotseat bawaan kalau ketemu
        content.postDelayed(() -> align(a, content, dock), 500);
    }

    static void align(Activity a, ViewGroup content, View dock) {
        try {
            View hs = null;
            for (String n : HOTSEAT_IDS) {
                int id = a.getResources().getIdentifier(n, "id", PKG);
                if (id != 0 && (hs = a.findViewById(id)) != null && hs.getHeight() > 0) break;
                hs = null;
            }
            if (hs == null || hs.getHeight() < dp(a, 60)) return;
            int[] h = new int[2], c = new int[2];
            hs.getLocationOnScreen(h);
            content.getLocationOnScreen(c);
            int height = Math.min(hs.getHeight(), dp(a, 112));
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) dock.getLayoutParams();
            p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            p.height = height;
            p.topMargin = h[1] - c[1] + (hs.getHeight() - height) / 2;
            p.bottomMargin = 0;
            dock.setLayoutParams(p);
        } catch (Throwable t) {
            XposedBridge.log("RoundedDock align: " + t);
        }
    }

    /** Wallpaper yang di-crop sesuai posisi dock, di-blur + saturasi tinggi. */
    static class BlurLayer extends View {
        static Drawable wp;
        static boolean loading;
        Bitmap bmp;
        final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

        BlurLayer(Context c) {
            super(c);
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(1.7f);
            ColorMatrix br = new ColorMatrix(new float[]{
                    1.08f, 0, 0, 0, 14, 0, 1.08f, 0, 0, 14, 0, 0, 1.08f, 0, 14, 0, 0, 0, 1, 0});
            cm.postConcat(br);
            paint.setColorFilter(new ColorMatrixColorFilter(cm));
            if (Build.VERSION.SDK_INT >= 31)
                setRenderEffect(android.graphics.RenderEffect.createBlurEffect(28f, 28f, Shader.TileMode.CLAMP));
        }

        void refresh() {
            if (getWidth() == 0 || getHeight() == 0) return;
            if (wp == null) {
                if (!loading) {
                    loading = true;
                    final Context ctx = getContext().getApplicationContext();
                    new Thread(() -> {
                        try { wp = WallpaperManager.getInstance(ctx).getDrawable(); }
                        catch (Throwable t) { XposedBridge.log("RoundedDock wp: " + t); }
                        loading = false;
                        post(this::refresh);
                    }).start();
                }
                return;
            }
            try {
                Activity act = (Activity) getContext();
                Rect sb = act.getWindowManager().getCurrentWindowMetrics().getBounds();
                int sw = sb.width(), sh = sb.height();
                int dw = Math.max(1, wp.getIntrinsicWidth()), dh = Math.max(1, wp.getIntrinsicHeight());
                float s = Math.max(sw / (float) dw, sh / (float) dh);
                float ox = (sw - dw * s) / 2f, oy = (sh - dh * s) / 2f;
                int[] l = new int[2];
                getLocationOnScreen(l);
                Bitmap b = Bitmap.createBitmap(Math.max(1, getWidth() / 4), Math.max(1, getHeight() / 4), Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b);
                c.scale(0.25f, 0.25f);
                c.translate(-l[0], -l[1]);
                c.translate(ox, oy);
                c.scale(s, s);
                wp.setBounds(0, 0, dw, dh);
                wp.draw(c);
                bmp = b;
                invalidate();
            } catch (Throwable t) {
                XposedBridge.log("RoundedDock blur: " + t);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (bmp != null) canvas.drawBitmap(bmp, null, new Rect(0, 0, getWidth(), getHeight()), paint);
            else canvas.drawColor(0x55808080);
        }
    }

    /** Lapisan kaca: tint putih, kilau atas, dan tepi specular ala liquid glass. */
    static class GlassOverlay extends View {
        final float r;
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
        final float sw;

        GlassOverlay(Context c, float radius) {
            super(c);
            r = radius;
            sw = dp(c, 1.3f);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(sw);
            inner.setStyle(Paint.Style.STROKE);
            inner.setStrokeWidth(dp(c, 5));
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            fill.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{0x55FFFFFF, 0x1FFFFFFF, 0x33FFFFFF}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            edge.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xE6FFFFFF, 0x1AFFFFFF, 0x66FFFFFF, 0x1AFFFFFF, 0xCCFFFFFF},
                    new float[]{0f, 0.3f, 0.5f, 0.7f, 1f}, Shader.TileMode.CLAMP));
            inner.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{0x40FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x22FFFFFF},
                    new float[]{0f, 0.25f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            RectF all = new RectF(0, 0, w, h);
            canvas.drawRoundRect(all, r, r, fill);
            float in = inner.getStrokeWidth() / 2f;
            canvas.drawRoundRect(new RectF(in, in, w - in, h - in), r - in, r - in, inner);
            float e = sw / 2f;
            canvas.drawRoundRect(new RectF(e, e, w - e, h - e), r - e, r - e, edge);
        }
    }
}
