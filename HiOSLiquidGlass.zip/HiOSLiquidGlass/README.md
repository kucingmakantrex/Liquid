# HiOS Liquid Glass (modul LSPosed)

Efek blur "liquid glass" untuk **dock**, **folder** (ikon di home + folder yang terbuka) dan **widget**
di HiOS Launcher (`com.transsion.hilauncher`, dianalisis dari versi 15.4.3.047).

## Cara pakai
1. Upload isi folder ini ke repo GitHub -> tab Actions -> jalankan "Build APK" -> unduh artifact `HiOS-Liquid-Glass`.
2. Pasang APK, aktifkan di LSPosed, scope: HiOS Launcher.
3. Buka aplikasi "HiOS Liquid Glass" sekali (supaya file pengaturan dibuat), atur, lalu restart launcher.

## Cara kerja
- Blur: `ViewRootImpl.createBackgroundBlurDrawable()` (blur lintas-window, sama seperti PLEnhanced/Pixel Launcher).
- Dock: hook `TrHotseatBackgroundHelper.drawRoundRect` (menggantikan gambar background dock bawaan).
- Ikon folder: hook `TrFolderPreviewBackground.drawBackground / drawBackgroundOnly`.
- Folder terbuka: `Folder.mBackground` diganti `GradientDrawable` khusus setelah `Folder.initView`.
- Widget: background `LauncherAppWidgetHostView` diganti drawable kaca.

## Log
Cari tag `[LiquidGlass]` di log LSPosed untuk melihat hook mana yang gagal.

## Catatan
- HiOS tidak punya background dock bawaan, jadi modul menggambar sendiri kaca di belakang ikon dock (jarak diatur lewat "Jarak kaca dari ikon dock").
- Widget yang punya background solid sendiri akan menutupi kaca.
- Tiap area kaca = 1 layer blur di SurfaceFlinger; banyak folder/widget bisa memberatkan GPU. Matikan "Ikon folder" kalau terasa berat.
- Kalau repo `api.xposed.info` gagal saat build, taruh `api-82.jar` di `app/libs/`.

## Diagnostik
Saat launcher dibuka muncul toast "Liquid Glass aktif. Hook: ..." (OK/GAGAL per bagian), lalu tiap bagian
menampilkan toast sekali saat pertama tergambar beserta status blur dan crossWindowBlur.
Tidak ada toast sama sekali = modul belum aktif/scope HiOS Launcher belum dicentang di LSPosed.
Matikan lewat saklar "Toast status" di aplikasi kalau sudah normal.
