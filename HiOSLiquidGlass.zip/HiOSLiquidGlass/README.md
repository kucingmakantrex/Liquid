# HiOS Liquid Glass (modul LSPosed)

Efek blur "liquid glass" untuk **dock**, **folder** (ikon di home + folder yang terbuka) dan **widget**
di HiOS Launcher (`com.transsion.hilauncher`, dianalisis dari versi 15.4.3.047).

## Cara pakai
1. Upload isi folder ini ke repo GitHub -> tab Actions -> jalankan "Build APK" -> unduh artifact `HiOS-Liquid-Glass`.
2. Pasang APK, aktifkan di LSPosed, scope: HiOS Launcher.
3. Buka aplikasi "HiOS Liquid Glass" sekali (supaya file pengaturan dibuat), atur, lalu restart launcher.

## Cara kerja
- Blur: `ViewRootImpl.createBackgroundBlurDrawable()` (blur lintas-window, sama seperti PLEnhanced/Pixel Launcher).
- Dock: hook `TrHotseatBackgroundHelper.drawRoundRect` (menggantikan gambar background dock bawaan).
- Ikon folder: hook `TrFolderPreviewBackground.drawBackground / drawBackgroundOnly`.
- Folder terbuka: `Folder.mBackground` diganti `GradientDrawable` khusus setelah `Folder.initView`.
- Widget: background `LauncherAppWidgetHostView` diganti drawable kaca.

## Log
Cari tag `[LiquidGlass]` di log LSPosed untuk melihat hook mana yang gagal.

## Catatan
- Background dock bawaan HiOS harus aktif (kalau di pengaturan HiOS dock tanpa background, hook dock tidak dipanggil).
- Widget yang punya background solid sendiri akan menutupi kaca.
- Tiap area kaca = 1 layer blur di SurfaceFlinger; banyak folder/widget bisa memberatkan GPU. Matikan "Ikon folder" kalau terasa berat.
- Kalau repo `api.xposed.info` gagal saat build, taruh `api-82.jar` di `app/libs/`.
