package com.ryo.liquidglass;

import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewParent;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Menggambar satu "panel kaca": blur latar (BackgroundBlurDrawable milik ViewRootImpl,
 * sama seperti yang dipakai Pixel Launcher / PLEnhanced), lapisan tint, kilap atas,
 * dan garis tepi gradien (rim light) ala liquid glass.
 */
final class GlassPainter {
    final View host;

    private Object root;
    private Drawable blur;
    private boolean blurDead;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF in = new RectF();

    private float kL, kT, kR, kB;
    private int kKey = -1;

    GlassPainter(View host) {
        this.host = host;
        rim.setStyle(Paint.Style.STROKE);
    }

    /** Alpha efektif view (dikalikan sampai beberapa parent). */
    static float effAlpha(View v) {
        float a = 1f;
        View x = v;
        for (int i = 0; i < 8 && x != null; i++) {
            a *= x.getAlpha();
            ViewParent p = x.getParent();
            x = p instanceof View ? (View) p : null;
        }
        return a;
    }

    private boolean isDark() {
        int t = HookCfg.i(Keys.THEME, Keys.D_THEME);
        if (t == 1) return false;
        if (t == 2) return true;
        int ui = host.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return ui == Configuration.UI_MODE_NIGHT_YES;
    }

    private Drawable ensureBlur() {
        if (blurDead) return null;
        try {
            Object r = XposedHelpers.callMethod(host, "getViewRootImpl");
            if (r == null) return null;
            if (r != root || blur == null) {
                root = r;
                blur = (Drawable) XposedHelpers.callMethod(r, "createBackgroundBlurDrawable");
            }
            return blur;
        } catch (Throwable t) {
            blurDead = true;
            XposedBridge.log(MainHook.TAG + "createBackgroundBlurDrawable gagal: " + t);
            return null;
        }
    }

    void draw(Canvas c, RectF r, float radius, float alpha) {
        if (r.width() < 2f || r.height() < 2f || alpha <= 0.01f) return;
        float d = host.getResources().getDisplayMetrics().density;
        int blurPx = Math.round(HookCfg.i(Keys.BLUR, Keys.D_BLUR) * d);
        int tintPct = HookCfg.i(Keys.TINT, Keys.D_TINT);
        int rimPct = HookCfg.i(Keys.RIM, Keys.D_RIM);
        boolean dark = isDark();

        // 1) blur latar
        if (blurPx > 0) {
            Drawable b = ensureBlur();
            if (b != null) {
                try {
                    b.setBounds(Math.round(r.left), Math.round(r.top),
                            Math.round(r.right), Math.round(r.bottom));
                    XposedHelpers.callMethod(b, "setBlurRadius", blurPx);
                    XposedHelpers.callMethod(b, "setCornerRadius", radius);
                    b.setAlpha(Math.round(255f * Math.min(1f, alpha)));
                    b.draw(c);
                } catch (Throwable t) {
                    blurDead = true;
                    XposedBridge.log(MainHook.TAG + "gambar blur gagal: " + t);
                }
            }
        }

        // 2) tint
        int base = dark ? 0x14161C : 0xFFFFFF;
        int a = Math.round(255f * tintPct / 100f);
        fill.setColor((a << 24) | base);
        c.drawRoundRect(r, radius, radius, fill);

        // 3) shader kilap & rim (dibuat ulang hanya jika ukuran/pengaturan berubah)
        int key = rimPct * 2 + (dark ? 1 : 0);
        if (key != kKey || r.left != kL || r.top != kT || r.right != kR || r.bottom != kB) {
            kKey = key;
            kL = r.left;
            kT = r.top;
            kR = r.right;
            kB = r.bottom;
            float k = rimPct / 100f;
            float sheenA = (dark ? 0.14f : 0.28f) * k;
            sheen.setShader(new LinearGradient(0f, r.top, 0f, r.top + r.height() * 0.55f,
                    ((int) (255 * sheenA) << 24) | 0xFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            float rs = dark ? 0.75f : 1f;
            int c0 = ((int) (255 * 0.90f * k * rs) << 24) | 0xFFFFFF;
            int c1 = ((int) (255 * 0.12f * k * rs) << 24) | 0xFFFFFF;
            int c2 = ((int) (255 * 0.10f * k * rs) << 24) | 0xFFFFFF;
            int c3 = ((int) (255 * 0.55f * k * rs) << 24) | 0xFFFFFF;
            rim.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                    new int[]{c0, c1, c2, c3}, new float[]{0f, 0.30f, 0.70f, 1f},
                    Shader.TileMode.CLAMP));
        }
        if (rimPct > 0) {
            c.drawRoundRect(r, radius, radius, sheen);
            float sw = Math.max(1f, 1.25f * d);
            rim.setStrokeWidth(sw);
            in.set(r);
            in.inset(sw / 2f, sw / 2f);
            c.drawRoundRect(in, Math.max(0f, radius - sw / 2f), Math.max(0f, radius - sw / 2f), rim);
        }
    }
}
