package com.ryo.liquidglass;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

/** Pengganti Folder.mBackground (bertipe GradientDrawable) untuk folder yang terbuka. */
final class FolderGlass extends GradientDrawable {
    private final View host;
    private final GlassPainter painter;
    private final RectF r = new RectF();

    FolderGlass(View host) {
        this.host = host;
        this.painter = new GlassPainter(host, "folder-open");
    }

    @Override
    public void draw(Canvas c) {
        if (!HookCfg.b(Keys.FOLDER_OPEN, true)) {
            super.draw(c);
            return;
        }
        Rect b = getBounds();
        if (b.isEmpty()) return;
        r.set(b);
        float d = host.getResources().getDisplayMetrics().density;
        int cfg = HookCfg.i(Keys.FOLDER_OPEN_R, 0);
        float own = 0f;
        try {
            own = getCornerRadius();
        } catch (Throwable ignored) {
        }
        float rad = cfg > 0 ? cfg * d : (own > 0f ? own : 28f * d);
        rad = Math.min(rad, Math.min(r.width(), r.height()) / 2f);
        painter.draw(c, r, rad, GlassPainter.effAlpha(host));
    }
}
