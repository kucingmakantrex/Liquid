package com.ryo.liquidglass;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Background kaca untuk LauncherAppWidgetHostView. */
final class WidgetGlass extends Drawable {
    private final View host;
    private final GlassPainter painter;
    private final RectF r = new RectF();

    WidgetGlass(View host) {
        this.host = host;
        this.painter = new GlassPainter(host);
    }

    @Override
    public void draw(Canvas c) {
        if (!HookCfg.b(Keys.WIDGET, true)) return;
        Rect b = getBounds();
        if (b.isEmpty()) return;
        r.set(b);
        Resources res = host.getResources();
        float d = res.getDisplayMetrics().density;
        int cfg = HookCfg.i(Keys.WIDGET_R, 0);
        float rad;
        if (cfg > 0) {
            rad = cfg * d;
        } else {
            int id = res.getIdentifier("system_app_widget_background_radius", "dimen", "android");
            rad = id != 0 ? res.getDimension(id) : 20f * d;
        }
        rad = Math.min(rad, Math.min(r.width(), r.height()) / 2f);
        painter.draw(c, r, rad, GlassPainter.effAlpha(host));
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter cf) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
