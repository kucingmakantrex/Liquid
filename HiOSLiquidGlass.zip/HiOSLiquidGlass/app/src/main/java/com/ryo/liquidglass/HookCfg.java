package com.ryo.liquidglass;

import android.content.SharedPreferences;
import android.os.SystemClock;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/** Pembaca pengaturan di dalam proses launcher (reload otomatis tiap ~2 detik). */
final class HookCfg {
    private static XSharedPreferences prefs;
    private static long lastCheck;

    static void init() {
        try {
            prefs = new XSharedPreferences(Keys.PKG, Keys.FILE);
            prefs.makeWorldReadable();
        } catch (Throwable t) {
            XposedBridge.log(MainHook.TAG + "prefs init gagal: " + t);
        }
    }

    private static SharedPreferences sp() {
        long now = SystemClock.uptimeMillis();
        if (now - lastCheck > 2000) {
            lastCheck = now;
            try {
                if (prefs.hasFileChanged()) prefs.reload();
            } catch (Throwable ignored) {
            }
        }
        return prefs;
    }

    static boolean b(String key, boolean def) {
        return prefs == null ? def : sp().getBoolean(key, def);
    }

    static int i(String key, int def) {
        return prefs == null ? def : sp().getInt(key, def);
    }

    private HookCfg() {}
}
