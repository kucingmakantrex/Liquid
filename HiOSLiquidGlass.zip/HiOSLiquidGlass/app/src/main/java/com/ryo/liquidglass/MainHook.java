package com.ryo.liquidglass;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String TAG = "[LiquidGlass] ";

    private static final Set<String> PKGS = new HashSet<>(Arrays.asList(
            "com.transsion.hilauncher", "com.transsion.XOSLauncher"));

    private final WeakHashMap<Object, GlassPainter> painters = new WeakHashMap<>();
    private final Set<String> logged = new HashSet<>();
    private final RectF tmp = new RectF();
    private boolean helperDrew;

    private interface Task {
        void run() throws Throwable;
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKGS.contains(lp.packageName)) return;
        HookCfg.init();
        final ClassLoader cl = lp.classLoader;
        safe("dock", () -> hookDock(cl));
        safe("folder-icon", () -> hookFolderIcon(cl));
        safe("folder-open", () -> hookFolderOpen(cl));
        safe("widget", () -> hookWidget(cl));
        XposedBridge.log(TAG + "aktif di " + lp.packageName + " -> " + Diag.hooks);
        safe("toast", () -> XposedHelpers.findAndHookMethod(android.app.Activity.class, "onResume",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Diag.once((android.content.Context) p.thisObject, "start",
                                "Liquid Glass aktif. Hook: " + Diag.hooks);
                    }
                }));
    }

    private void safe(String name, Task t) {
        try {
            t.run();
        } catch (Throwable e) {
            XposedBridge.log(TAG + "hook " + name + " gagal: " + e);
        }
        if (!name.equals("toast")) Diag.hook(name, Diag.installed.contains(name));
    }

    private void logOnce(String key, Throwable t) {
        if (logged.add(key)) XposedBridge.log(TAG + key + ": " + t);
    }

    private GlassPainter painterFor(Object key, View host, String area) {
        GlassPainter p = painters.get(key);
        if (p == null || p.host != host) {
            p = new GlassPainter(host, area);
            painters.put(key, p);
        }
        return p;
    }

    // ---------------------------------------------------------------- DOCK
    private void hookDock(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClassIfExists(
                "com.android.launcher3.TrHotseatBackgroundHelper", cl);
        if (c == null) {
            XposedBridge.log(TAG + "TrHotseatBackgroundHelper tidak ditemukan");
            return;
        }
        XposedHelpers.findAndHookMethod(c, "drawRoundRect",
                Canvas.class, float.class, int.class, boolean.class, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            if (!HookCfg.b(Keys.DOCK, true)) return;
                            RectF rect = (RectF) XposedHelpers.getObjectField(p.thisObject, "rectF");
                            View host = (View) XposedHelpers.getObjectField(p.thisObject, "hotSeat");
                            if (rect == null || host == null || rect.isEmpty()) return;
                            float d = host.getResources().getDisplayMetrics().density;
                            float half = Math.min(rect.width(), rect.height()) / 2f;
                            int cfg = HookCfg.i(Keys.DOCK_R, 0);
                            float rad;
                            if (cfg > 0) {
                                rad = cfg * d;
                            } else {
                                rad = half;
                                try {
                                    Object lazy = XposedHelpers.getObjectField(p.thisObject, "maxRadius$delegate");
                                    Object v = XposedHelpers.callMethod(lazy, "getValue");
                                    if (v instanceof Number) rad = ((Number) v).floatValue();
                                } catch (Throwable ignored) {
                                }
                            }
                            rad = Math.min(rad, half);
                            painterFor(p.thisObject, host, "dock").draw((Canvas) p.args[0], rect, rad,
                                    GlassPainter.effAlpha(host));
                            helperDrew = true;
                            p.setResult(null);
                        } catch (Throwable t) {
                            logOnce("dock", t);
                        }
                    }
                });

        // HiOS tidak selalu punya background dock: kalau helper bawaan tidak menggambar,
        // gambar sendiri kaca di belakang ikon-ikon dock.
        Class<?> hs = XposedHelpers.findClassIfExists("com.android.launcher3.TrHotseat", cl);
        if (hs == null) {
            XposedBridge.log(TAG + "TrHotseat tidak ditemukan");
            return;
        }
        XposedHelpers.findAndHookMethod(hs, "onDraw", Canvas.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                helperDrew = false;
            }

            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if (!helperDrew) drawOwnDock(p);
            }
        });
        Diag.installed.add("dock");
    }

    private void drawOwnDock(XC_MethodHook.MethodHookParam p) {
        try {
            if (!HookCfg.b(Keys.DOCK, true)) return;
            if (!(p.thisObject instanceof ViewGroup)) return;
            ViewGroup host = (ViewGroup) p.thisObject;
            ViewGroup sw = null;
            try {
                sw = (ViewGroup) XposedHelpers.callMethod(host, "getShortcutsAndWidgets");
            } catch (Throwable ignored) {
            }
            ViewGroup src = sw != null ? sw : host;
            float ox = sw != null ? sw.getLeft() : 0f;
            float oy = sw != null ? sw.getTop() : 0f;
            float l = Float.MAX_VALUE, t = Float.MAX_VALUE, r = -1f, b = -1f;
            int n = 0;
            for (int i = 0; i < src.getChildCount(); i++) {
                View v = src.getChildAt(i);
                if (v.getVisibility() != View.VISIBLE) continue;
                l = Math.min(l, v.getLeft() + ox);
                t = Math.min(t, v.getTop() + oy);
                r = Math.max(r, v.getRight() + ox);
                b = Math.max(b, v.getBottom() + oy);
                n++;
            }
            if (n == 0) return;
            float d = host.getResources().getDisplayMetrics().density;
            float pad = HookCfg.i(Keys.DOCK_PAD, Keys.D_DOCK_PAD) * d;
            tmp.set(Math.max(0f, l - pad), Math.max(0f, t - pad * 0.6f),
                    Math.min(host.getWidth(), r + pad), Math.min(host.getHeight(), b + pad * 0.6f));
            if (tmp.isEmpty()) return;
            float half = Math.min(tmp.width(), tmp.height()) / 2f;
            int cfg = HookCfg.i(Keys.DOCK_R, 0);
            float rad = Math.min(cfg > 0 ? cfg * d : half, half);
            painterFor(host, host, "dock").draw((Canvas) p.args[0], tmp, rad, GlassPainter.effAlpha(host));
        } catch (Throwable t) {
            logOnce("dock-own", t);
        }
    }

    // ----------------------------------------------------------- FOLDER ICON
    private void hookFolderIcon(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClassIfExists(
                "com.android.launcher3.folder.TrFolderPreviewBackground", cl);
        if (c == null) {
            XposedBridge.log(TAG + "TrFolderPreviewBackground tidak ditemukan");
            return;
        }
        XposedHelpers.findAndHookMethod(c, "drawBackground", Canvas.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                drawFolderIcon(p, true);
            }
        });
        XposedHelpers.findAndHookMethod(c, "drawBackgroundOnly", Canvas.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                drawFolderIcon(p, false);
            }
        });
        Diag.installed.add("folder-icon");
    }

    private void drawFolderIcon(XC_MethodHook.MethodHookParam p, boolean translate) {
        try {
            if (!HookCfg.b(Keys.FOLDER_ICON, true)) return;
            Drawable bg = (Drawable) XposedHelpers.getObjectField(p.thisObject, "mBackground");
            View host = (View) XposedHelpers.getObjectField(p.thisObject, "mInvalidateView");
            if (bg == null || host == null) return;
            Rect b = bg.getBounds();
            if (b.isEmpty()) return;
            tmp.set(b);
            float d = host.getResources().getDisplayMetrics().density;
            float half = Math.min(tmp.width(), tmp.height()) / 2f;
            int cfg = HookCfg.i(Keys.FOLDER_ICON_R, 0);
            float rad;
            if (cfg > 0) {
                rad = cfg * d;
            } else if (bg instanceof GradientDrawable
                    && ((GradientDrawable) bg).getShape() == GradientDrawable.OVAL) {
                rad = half;
            } else {
                rad = 0f;
                if (bg instanceof GradientDrawable) {
                    try {
                        rad = ((GradientDrawable) bg).getCornerRadius();
                    } catch (Throwable ignored) {
                    }
                }
                if (rad <= 0f) rad = half * 0.62f;
            }
            rad = Math.min(rad, half);
            Canvas c = (Canvas) p.args[0];
            GlassPainter gp = painterFor(p.thisObject, host, "folder-icon");
            float alpha = GlassPainter.effAlpha(host);
            if (translate) {
                int ox = XposedHelpers.getIntField(p.thisObject, "mPreviewOffsetX");
                int oy = XposedHelpers.getIntField(p.thisObject, "mPreviewOffsetY");
                c.save();
                c.translate(ox, oy);
                gp.draw(c, tmp, rad, alpha);
                c.restore();
            } else {
                gp.draw(c, tmp, rad, alpha);
            }
            p.setResult(null);
        } catch (Throwable t) {
            logOnce("folder-icon", t);
        }
    }

    // ----------------------------------------------------------- FOLDER OPEN
    private void hookFolderOpen(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClassIfExists("com.android.launcher3.folder.Folder", cl);
        if (c == null) {
            XposedBridge.log(TAG + "Folder tidak ditemukan");
            return;
        }
        XposedHelpers.findAndHookMethod(c, "initView", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object old = XposedHelpers.getObjectField(p.thisObject, "mBackground");
                    if (old instanceof FolderGlass) return;
                    FolderGlass g = new FolderGlass((View) p.thisObject);
                    if (old instanceof GradientDrawable) {
                        float cr = ((GradientDrawable) old).getCornerRadius();
                        if (cr > 0f) g.setCornerRadius(cr);
                    }
                    XposedHelpers.setObjectField(p.thisObject, "mBackground", g);
                } catch (Throwable t) {
                    logOnce("folder-open", t);
                }
            }
        });
        Diag.installed.add("folder-open");
    }

    // ---------------------------------------------------------------- WIDGET
    private void hookWidget(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClassIfExists(
                "com.android.launcher3.widget.LauncherAppWidgetHostView", cl);
        if (c == null) {
            XposedBridge.log(TAG + "LauncherAppWidgetHostView tidak ditemukan");
            return;
        }
        XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    View v = (View) p.thisObject;
                    if (!(v.getBackground() instanceof WidgetGlass)) {
                        v.setBackground(new WidgetGlass(v));
                    }
                } catch (Throwable t) {
                    logOnce("widget", t);
                }
            }
        });
        Diag.installed.add("widget");
    }
}
