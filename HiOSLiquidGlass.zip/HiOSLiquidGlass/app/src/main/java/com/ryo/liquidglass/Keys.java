package com.ryo.liquidglass;

/** Kunci & nilai default pengaturan (dipakai app dan hook). Tanpa dependensi Xposed. */
final class Keys {
    static final String PKG = "com.ryo.liquidglass";
    static final String FILE = "cfg";

    static final String DOCK = "dock";
    static final String FOLDER_ICON = "folder_icon";
    static final String FOLDER_OPEN = "folder_open";
    static final String WIDGET = "widget";

    static final String BLUR = "blur";     // dp
    static final String TINT = "tint";     // persen
    static final String RIM = "rim";       // persen (kekuatan pinggiran & kilap)
    static final String THEME = "theme";   // 0 auto, 1 terang, 2 gelap

    static final String DOCK_R = "dock_r";               // dp, 0 = otomatis
    static final String FOLDER_ICON_R = "folder_icon_r"; // dp, 0 = otomatis
    static final String FOLDER_OPEN_R = "folder_open_r"; // dp, 0 = otomatis
    static final String WIDGET_R = "widget_r";           // dp, 0 = otomatis

    static final String DEBUG = "debug";                 // toast diagnostik
    static final String DOCK_PAD = "dock_pad";           // dp, jarak kaca dari ikon dock

    static final int D_DOCK_PAD = 10;
    static final int D_BLUR = 24;
    static final int D_TINT = 16;
    static final int D_RIM = 70;
    static final int D_THEME = 0;

    private Keys() {}
}
