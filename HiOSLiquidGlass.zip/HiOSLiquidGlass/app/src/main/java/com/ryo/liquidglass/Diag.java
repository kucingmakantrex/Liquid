package com.ryo.liquidglass;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.XposedBridge;

/** Diagnostik: toast + log supaya kelihatan tahap mana yang gagal. */
final class Diag {
    static final Set<String> installed = new HashSet<>();
    static final StringBuilder hooks = new StringBuilder();
    private static final Set<String> shown = new HashSet<>();
    private static Handler handler;

    static void hook(String name, boolean ok) {
        hooks.append(name).append(ok ? " OK, " : " GAGAL, ");
    }

    static void toast(Context c, String msg) {
        Log.i("LiquidGlass", msg);
        XposedBridge.log(MainHook.TAG + msg);
        if (c == null || !HookCfg.b(Keys.DEBUG, true)) return;
        try {
            if (handler == null) handler = new Handler(Looper.getMainLooper());
            final Context app = c.getApplicationContext() != null ? c.getApplicationContext() : c;
            final String m = msg;
            handler.post(() -> {
                try {
                    Toast.makeText(app, m, Toast.LENGTH_LONG).show();
                } catch (Throwable ignored) {
                }
            });
        } catch (Throwable ignored) {
        }
    }

    static void once(Context c, String key, String msg) {
        if (shown.add(key)) toast(c, msg);
    }

    private Diag() {}
}
