package com.ryo.liquidglass;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private SharedPreferences sp;
    private LinearLayout root;

    @SuppressLint("WorldReadableFiles")
    @SuppressWarnings("deprecation")
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences(Keys.FILE, MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            Toast.makeText(this, "Aktifkan modul di LSPosed dulu, lalu buka ulang aplikasi ini",
                    Toast.LENGTH_LONG).show();
            return getSharedPreferences(Keys.FILE, MODE_PRIVATE);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = prefs();

        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(40), dp(18), dp(32));
        sv.addView(root);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("HiOS Liquid Glass");
        title.setTextSize(24f);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Aktifkan modul di LSPosed (scope: HiOS Launcher). Perubahan di sini "
                + "diterapkan otomatis dalam beberapa detik; kalau belum berubah, tekan "
                + "tombol restart di bawah.");
        hint.setPadding(0, dp(6), 0, dp(14));
        root.addView(hint);

        section("Bagian yang diberi efek");
        sw("Dock", Keys.DOCK);
        sw("Ikon folder (di home)", Keys.FOLDER_ICON);
        sw("Folder yang terbuka", Keys.FOLDER_OPEN);
        sw("Widget", Keys.WIDGET);

        section("Diagnostik");
        sw("Toast status (matikan kalau sudah normal)", Keys.DEBUG);

        section("Tampilan kaca");
        seek("Kekuatan blur", Keys.BLUR, 0, 80, Keys.D_BLUR, " dp");
        seek("Tint (kepekatan)", Keys.TINT, 0, 60, Keys.D_TINT, " %");
        seek("Kilap & garis tepi", Keys.RIM, 0, 100, Keys.D_RIM, " %");
        theme();
        seek("Jarak kaca dari ikon dock", Keys.DOCK_PAD, 0, 30, Keys.D_DOCK_PAD, " dp");

        section("Sudut membulat (0 = otomatis)");
        seek("Dock", Keys.DOCK_R, 0, 60, 0, " dp");
        seek("Ikon folder", Keys.FOLDER_ICON_R, 0, 60, 0, " dp");
        seek("Folder terbuka", Keys.FOLDER_OPEN_R, 0, 60, 0, " dp");
        seek("Widget", Keys.WIDGET_R, 0, 60, 0, " dp");

        Button restart = new Button(this);
        restart.setText("Restart HiOS Launcher (root)");
        restart.setOnClickListener(v -> new Thread(() -> {
            try {
                Runtime.getRuntime().exec(new String[]{"su", "-c",
                        "am force-stop com.transsion.hilauncher"}).waitFor();
            } catch (Throwable ignored) {
            }
        }).start());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(20);
        root.addView(restart, lp);
    }

    private void section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(16f);
        t.setPadding(0, dp(18), 0, dp(6));
        root.addView(t);
    }

    private void sw(String label, String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(key, true));
        s.setPadding(0, dp(6), 0, dp(6));
        s.setOnCheckedChangeListener((v, on) -> sp.edit().putBoolean(key, on).apply());
        root.addView(s);
    }

    private void seek(String label, String key, int min, int max, int def, String unit) {
        TextView t = new TextView(this);
        int cur = sp.getInt(key, def);
        t.setText(label + ": " + cur + unit);
        t.setPadding(0, dp(8), 0, 0);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(cur - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                int v = p + min;
                t.setText(label + ": " + v + unit);
                if (fromUser) sp.edit().putInt(key, v).apply();
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        root.addView(t);
        root.addView(s);
    }

    private void theme() {
        TextView t = new TextView(this);
        t.setText("Warna kaca");
        t.setPadding(0, dp(10), 0, 0);
        Spinner sp2 = new Spinner(this);
        sp2.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Otomatis (ikut mode gelap sistem)", "Terang", "Gelap"}));
        sp2.setSelection(sp.getInt(Keys.THEME, Keys.D_THEME));
        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                sp.edit().putInt(Keys.THEME, pos).apply();
            }

            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        root.addView(t);
        root.addView(sp2);
    }
}
